# Supply Chain Optimization Dashboard

A Streamlit dashboard prototype for the Majmaah University supply-chain optimization project.

## Deploy without Kaggle or ngrok

### 1. Upload these files to GitHub
Create a repository (for example, `supply-chain-dashboard`) and upload:
- `app.py`
- `requirements.txt`

Keep both files in the repository root.

### 2. Deploy on Streamlit Community Cloud
1. Open https://share.streamlit.io/ and sign in with GitHub.
2. Select **Create app**.
3. Choose your repository, branch (`main`), and main file path (`app.py`).
4. Click **Deploy**.
5. Streamlit will provide a public app URL ending in `streamlit.app`.

Official guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy

## Important project note
This is currently a **dashboard prototype**. The KPIs and chart allocations are hard-coded demonstration values; the script does not yet formulate or solve a MILP optimization model. The capacity-flexibility slider is currently a visual control and does not recalculate the solution. Do not present the displayed values as verified results until the real dataset and optimization model are connected.
