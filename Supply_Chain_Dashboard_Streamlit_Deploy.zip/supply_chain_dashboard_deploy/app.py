import pandas as pd
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(
    page_title="Supply Chain Decision Support System",
    page_icon="📦",
    layout="wide",
)

st.title("A Data-Driven Decision Support System for Supply Chain Optimization")
st.markdown("Majmaah University - College of Science | Department of Mathematics & Statistics")

# Sidebar controls
st.sidebar.header("Control Panel & Scenario Sliders")
shipping_day = st.sidebar.selectbox("Select Shipping Day:", [1, 2, 3, 4, 5, 6])
capacity_buffer_pct = st.sidebar.slider("Capacity Flexibility Buffer (%)", 80, 120, 100)
capacity_buffer = capacity_buffer_pct / 100.0

st.sidebar.markdown("---")
st.sidebar.subheader("Historical Bottleneck Fix")
st.sidebar.info(
    "Dataset example (2013-05-26):\n\n"
    "- PLANT03 limit: 1,013 (manual: 4,148; displayed optimized: 1,013)\n"
    "- PLANT08 limit: 14 (manual: 80; displayed optimized: 14)"
)

# KPI cards: fixed values from the supplied brief, not calculated by this demo.
col1, col2, col3, col4 = st.columns(4)
col1.metric("Optimal Total Cost", "$1,248,500", "-22.4% Savings")
col2.metric("Processed Orders", "9,215 / 9,215", "100% Completed")
col3.metric("Active Plants", "19 / 19 Plants", "Balanced Load")
col4.metric("Capacity Violations", "0.0%", "Zero Overload Delays")

st.caption(
    "Prototype note: The KPI values and chart allocations below are hard-coded examples. "
    "This script displays the dashboard but does not yet build or solve a MILP optimization model. "
    "The capacity slider is currently a visual control and does not recalculate allocations."
)
st.markdown("---")

# Demonstration comparison data
st.subheader(f"Plant Workload Comparison: Manual vs. MILP Model (Day {shipping_day})")
chart_data = pd.DataFrame(
    {
        "Plant": ["PLANT01", "PLANT02", "PLANT03", "PLANT08", "PLANT09"],
        "Manual Method": [850, 620, 4148, 80, 540],
        "MILP Model": [910, 750, 1013, 14, 590],
        "Max Limit": [1000, 800, 1013, 14, 600],
    }
)

fig = go.Figure()
fig.add_trace(
    go.Bar(
        x=chart_data["Plant"],
        y=chart_data["Manual Method"],
        name="Manual Method (Legacy)",
    )
)
fig.add_trace(
    go.Bar(
        x=chart_data["Plant"],
        y=chart_data["MILP Model"],
        name="MILP Model (Optimized)",
    )
)
fig.add_trace(
    go.Scatter(
        x=chart_data["Plant"],
        y=chart_data["Max Limit"],
        name="Max Limit",
        mode="lines+markers",
        line=dict(dash="dash"),
    )
)
fig.update_layout(
    title="Daily Workload Allocation vs. Plant Capacity Thresholds",
    xaxis_title="Plant ID",
    yaxis_title="Number of Orders Assigned",
    barmode="group",
    legend_title="Series",
)
st.plotly_chart(fig, width="stretch")

# Example order-allocation table
st.subheader("Order Routing & Assignment Details")
sample_allocations = pd.DataFrame(
    {
        "Order_ID": ["ORD_0001", "ORD_0002", "ORD_0003", "ORD_0004"],
        "Quantity": [120, 85, 200, 45],
        "Shipping Day": [shipping_day] * 4,
        "Assigned Plant": ["PLANT01", "PLANT03", "PLANT02", "PLANT08"],
        "Calculated Cost": ["$1,420.00", "$950.50", "$2,100.00", "$320.00"],
    }
)
st.dataframe(sample_allocations, width="stretch", hide_index=True)
